<?php

require_once('Download.php');

$download = new Download();

if (isset($_POST['link'])){

    $url = $_POST['link'];

     $download = $download->get_download($url);

     include 'index.php';

}



