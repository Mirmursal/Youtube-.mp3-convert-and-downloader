<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <title>Document</title>

</head>
<body>
<div class="container">
    <h3 class="text-center">Youtube Downloader(convert to .mp3 and download)</h3>
    <div>
        <form action="action.php" method="post">
            <div class="form-group">
                <label for="link">Url Linki daxil edin</label>
                <input type="text" class="form-control" id="link" name="link">
            </div>
            <div class="form-group">
                <button class="btn btn-primary">Endirmə Linkinə Get</button>
            </div>
        </form>
    </div>
    <div class="row">
        <?php if(isset($download)){
            $src = 'https://www.download-mp3-youtube.com/api/?api_key=MzIxMzcwOTQ4&format=mp3&video_id='.$download;
            ?>
            <div class="col-md-3">
                <!--download link iframe-->
                <iframe width="250px"
                        height="60px"
                        scrolling="no"
                        style="border:none;"
                        src="<?php echo $src?>">
                </iframe>
            </div>
            <div class="col-md-3" style="   margin-top: 10px;">
                <!--refresh link-->
                <a href="index.php" style="font-size: 28px;
                                color: #ca3030;
                        text-decoration: none;">
                    Yenilə
                    <i class="fa fa-refresh" aria-hidden="true"></i>
                </a>
            </div>
        <?php } ?>
    </div>
</div>

</body>
</html>