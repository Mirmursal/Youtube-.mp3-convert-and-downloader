<?php

 class Download
{

     function get_download($link){

        $url = $link;

        parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );

        $data['link'] = $my_array_of_vars['v'];

        return $data['link'];

    }
}
