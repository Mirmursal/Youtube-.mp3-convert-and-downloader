<?php

class Todo extends CI_Controller{

    public function __construct()
    {

        parent::__construct();

    }

    public function index(){

        $this->load->view('todo_list');

    }

    public function get_download(){

        $link = $this->input->post('link');

        $url = $link;

        parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );

        $data['link'] = $my_array_of_vars['v'];

        $this->load->view('todo_list' , $data);

   }

}
