<script src="<?php echo base_url("assets/js/jquery-3.3.1.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/switchery.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/custom.js"); ?>"></script>